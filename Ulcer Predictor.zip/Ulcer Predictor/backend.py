from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import google.generativeai as genai
import uvicorn
import os
from typing import Optional

# Configure Gemini AI
genai.configure(api_key="AIzaSyDtVOUVmBR1g6EDT9csrqzM1-ukUlQkbwI")

# System prompt for medical analysis
SYSTEM_PROMPT = """
You are an advanced AI medical image analysis system, specialized in assisting healthcare professionals in diagnosing diseases from medical images such as X-rays, CT scans, MRIs, and ultrasound images.

Your responsibilities include:

1. Detailed Image Examination:
- Carefully analyze each medical image to detect potential abnormalities.
- Tumors (benign or malignant)
- Fractures and bone abnormalities
- Infections or inflammatory conditions
- Organ enlargement or shrinkage
- Vascular abnormalities
- Pathological changes in soft tissues
- Detect both subtle and significant changes, ensuring that even minor anomalies are identified.

2. Specific Disease Detection:
- Apply domain-specific knowledge to recognize conditions such as:
- Cancer (e.g., lung cancer, breast cancer, brain tumors)
- Cardiovascular diseases (e.g., heart disease, aneurysms, stroke)
- Neurological conditions (e.g., brain hemorrhage, multiple sclerosis)
- Musculoskeletal disorders (e.g., fractures, arthritis, bone degeneration)
- Pulmonary diseases (e.g., pneumonia, tuberculosis, COPD)
- Gastrointestinal diseases (e.g., cirrhosis, Crohn's disease)
- For each condition detected, assess the stage, severity, and affected regions.

3. Contextual Analysis:
- Consider the context of the medical image, including patient history, imaging modality, and anatomical location.
- Provide insights that help clinicians understand the possible causes and implications of the findings.

4. Structured Medical Reporting:
Provide results in a clear and structured format including:
- Detected abnormalities
- Possible diagnosis
- Confidence level
- Severity assessment
- Recommendations for further medical evaluation or tests

5. Accuracy and Sensitivity:
- Ensure high sensitivity to ensure no serious conditions are overlooked.
- Maintain high specificity to reduce false positives and avoid unnecessary concern.
- Ensure the analysis is consistent with current medical standards.

6. Ethical Considerations:
- Provide a neutral and unbiased assessment, ensuring fairness in analysis.
- Make sure the diagnosis does not provide overly alarming results without sufficient evidence.

Your task is to assist healthcare professionals by delivering highly accurate, clear, and structured medical image analysis to support clinical decision making.
"""

# AI Configuration
GENERATION_CONFIG = {
    "temperature": 0.7,
    "top_p": 0.95,
    "max_output_tokens": 2048,
}

SAFETY_SETTINGS = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

app = FastAPI(title="Medical Image Analysis API", description="AI-powered medical image analysis for healthcare professionals")

# Serve static files (CSS, JS, etc.)
app.mount("/static", StaticFiles(directory="."), name="static")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the main frontend page"""
    with open("index.html", "r", encoding="utf-8") as f:
        return f.read()

@app.post("/api/analyze")
async def analyze_image(file: UploadFile = File(...)):
    """Analyze uploaded medical image"""
    try:
        # Validate file type
        if not file.content_type in ["image/jpeg", "image/jpg", "image/png"]:
            raise HTTPException(status_code=400, detail="Only JPEG, JPG, and PNG images are supported")

        # Read image data
        image_data = await file.read()

        # Initialize AI model
        model = genai.GenerativeModel(
            model_name="gemini-flash-latest",
            generation_config=GENERATION_CONFIG,
            safety_settings=SAFETY_SETTINGS,
        )

        # Prepare prompt parts
        prompt_parts = [
            {
                "mime_type": file.content_type,
                "data": image_data
            },
            {
                "text": SYSTEM_PROMPT + "\n\nPlease analyze this medical image and provide a detailed diagnosis report."
            }
        ]

        # Generate analysis
        response = model.generate_content(prompt_parts)

        return {
            "success": True,
            "analysis": response.text,
            "filename": file.filename,
            "file_size": len(image_data)
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "Medical Image Analysis API"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)