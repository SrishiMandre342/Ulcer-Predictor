import streamlit as st
import google.generativeai as genai

genai.configure(api_key="AIzaSyDtVOUVmBR1g6EDT9csrqzM1-ukUlQkbwI")

# prompt

system_prompt = """
You are an advanced AI medical image analysis system, specialized in assisting healthcare professionals in diagnosing diseases from medical images such as X-rays, CT scans, MRIs, and ultrasound images.

Your responsibilities include:

1. Detailed Image Examination:
- Carefully analyze each medical image to detect potential abnormalities.
- Tumors (benign or malignant)
- Fractures and bone abnormalities
- Infections or inflammatory conditions
- Organ enlargement or shrinkage
- Vascular abnormalities
- Pathological changes in soft tissues
- Detect both subtle and significant changes, ensuring that even minor anomalies are identified.

2. Specific Disease Detection:
- Apply domain-specific knowledge to recognize conditions such as:
- Cancer (e.g., lung cancer, breast cancer, brain tumors)
- Cardiovascular diseases (e.g., heart disease, aneurysms, stroke)
- Neurological conditions (e.g., brain hemorrhage, multiple sclerosis)
- Musculoskeletal disorders (e.g., fractures, arthritis, bone degeneration)
- Pulmonary diseases (e.g., pneumonia, tuberculosis, COPD)
- Gastrointestinal diseases (e.g., cirrhosis, Crohn's disease)
- For each condition detected, assess the stage, severity, and affected regions.

3. Contextual Analysis:
- Consider the context of the medical image, including patient history, imaging modality, and anatomical location.
- Provide insights that help clinicians understand the possible causes and implications of the findings.

4. Structured Medical Reporting:
Provide results in a clear and structured format including:
- Detected abnormalities
- Possible diagnosis
- Confidence level
- Severity assessment
- Recommendations for further medical evaluation or tests

5. Accuracy and Sensitivity:
- Ensure high sensitivity to ensure no serious conditions are overlooked.
- Maintain high specificity to reduce false positives and avoid unnecessary concern.
- Ensure the analysis is consistent with current medical standards.

6. Ethical Considerations:
- Provide a neutral and unbiased assessment, ensuring fairness in analysis.
- Make sure the diagnosis does not provide overly alarming results without sufficient evidence.

Your task is to assist healthcare professionals by delivering highly accurate, clear, and structured medical image analysis to support clinical decision making.
"""

generation_config = {
    "temperature": 0.7,
    "top_p": 0.95,
    "max_output_tokens": 2048,
}

safety_settings = [
    {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
    {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"},
]

# layout
st.set_page_config(page_title="MediScan AI", page_icon="🏥", layout="wide")

# Custom styles to emulate a professional medical website
st.markdown("""
<style>
body, .css-17lntkn, .block-container {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 60%);
    color: #e2e8f0;
}

.css-1d391kg {
    box-shadow: none;
}

h1, h2, h3, h4, h5, h6, p {
    color: #f8fafc !important;
}

.stButton>button {
    color: white;
    background: linear-gradient(45deg, #3b82f6, #2563eb);
    border: none;
    border-radius: 12px;
    padding: 10px 18px;
    font-weight: 700;
}

.stButton>button:hover {
    transform: translateY(-1px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

.stFileUploader {
    background: rgba(255,255,255,0.95);
    border: 2px dashed #0ea5e9;
    border-radius: 14px;
    padding: 20px;
}

.stAlert {
    border-radius: 10px;
    padding: 1rem;
}

.result-box {
    background: rgba(15,23,42,0.85);
    border: 1px solid rgba(148,163,184,0.4);
    color: #e2e8f0;
    border-radius: 14px;
    padding: 18px;
    margin-top: 16px;
}

@media (max-width: 768px) {
    .css-1hynsf2 {
        padding: 1rem;
    }
}
</style>
""", unsafe_allow_html=True)

# Top navigation style via markdown
st.markdown("""
<nav style='display: flex; justify-content: space-between; align-items: center; width: 100%; margin-bottom: 2rem;'>
  <div style='font-size: 1.4rem; font-weight: 900;'>🏥 MediScan AI</div>
  <div>
    <a href='#home' style='color: #dbeafe; margin-right: 1rem; text-decoration:none;'>Home</a>
    <a href='#features' style='color: #dbeafe; margin-right: 1rem; text-decoration:none;'>Features</a>
    <a href='#upload' style='color: #dbeafe; margin-right: 1rem; text-decoration:none;'>Upload</a>
    <a href='#about' style='color: #dbeafe; text-decoration:none;'>About</a>
  </div>
</nav>
""", unsafe_allow_html=True)

# Hero section
st.markdown("""
<div id='home' style='display:flex; gap: 2rem; width:100%; margin-bottom:3rem; flex-wrap:wrap;'>
  <div style='flex:1; min-width:300px;'>
    <h1 style='font-size:3rem; margin-bottom:0.4rem;'>Advanced AI-Powered Medical Diagnostics</h1>
    <p style='font-size:1.2rem; color:#c7d2fe;'>Delivering fast and accurate medical image analysis for clinicians and medical researchers.</p>
    <div style='margin-top:1.5rem;'>
      <a href='#upload' style='text-decoration:none;'><button style='background: #22d3ee; color:#0f172a; border:none; padding:12px 22px; border-radius:10px; font-weight:700; margin-right:10px;'>🚀 Start Analysis</button></a>
      <a href='#features' style='text-decoration:none;'><button style='background: rgba(255,255,255,0.2); color:#f8fafc; border:1px solid #dbeafe; padding:12px 22px; border-radius:10px; font-weight:700;'>📘 Learn More</button></a>
    </div>
  </div>
  <div style='flex:1; min-width:300px; display:flex; justify-content:center; align-items:center;'>
    <div style='width:220px; height:220px; border-radius:50%; background: radial-gradient(circle at 30% 30%, #93c5fd, #1d4ed8); display:flex; justify-content:center; align-items:center;'>
      <span style='font-size:4rem; color:#f8fafc;'>🩺</span>
    </div>
  </div>
</div>
""", unsafe_allow_html=True)

# Features section
st.markdown("""
<div id='features' style='display:grid; grid-template-columns: repeat(auto-fit, minmax(220px,1fr)); gap:1rem; margin-bottom:2rem;'>
  <div style='background: rgba(15,23,42,0.8); border: 1px solid rgba(59,130,246,0.45); border-radius:12px; padding:1rem;'>
    <h3>✅ AI Diagnosis</h3><p>Gemini AI model for medical images.</p>
  </div>
  <div style='background: rgba(15,23,42,0.8); border: 1px solid rgba(59,130,246,0.45); border-radius:12px; padding:1rem;'>
    <h3>⚡ Fast Results</h3><p>Instant processing and report generation.</p>
  </div>
  <div style='background: rgba(15,23,42,0.8); border: 1px solid rgba(59,130,246,0.45); border-radius:12px; padding:1rem;'>
    <h3>🔒 Secure</h3><p>In-memory analysis, no file persistence.</p>
  </div>
</div>
""", unsafe_allow_html=True)

# Upload and analysis section
st.markdown("""
<div id='upload' style='background: rgba(255,255,255,0.09); border-radius:16px; padding:2rem; border:1px solid rgba(148,163,184,0.4); margin-bottom:2rem;'>
  <h2>📤 Medical Image Analysis</h2>
  <p>Upload an X-ray, MRI, or CT image and receive an AI-assisted diagnostic report.</p>
</div>
""", unsafe_allow_html=True)

upload_file = st.file_uploader(
    "Choose an image to scan (JPG / PNG / JPEG)",
    type=["jpg", "png", "jpeg"],
    help="Max 10MB"
)

submit_button = st.button("🔍 Generate Diagnostic Report")

if submit_button:
    if upload_file is None:
        st.error("⚠️ Please upload a medical image first.")
    else:
        try:
            with st.spinner("🩺 Analyzing image... please wait"):
                image_data = upload_file.getvalue()
                mime_type = upload_file.type
                model = genai.GenerativeModel(
                    model_name="gemini-flash-latest",
                    generation_config=generation_config,
                    safety_settings=safety_settings,
                )
                prompt_parts = [
                    {"mime_type": mime_type, "data": image_data},
                    {"text": system_prompt + "\n\nPlease analyze this medical image and provide a detailed diagnosis report."}
                ]
                response = model.generate_content(prompt_parts)
                st.success("✅ Analysis Complete")
                st.markdown(f"<div class='result-box'><h3>📋 Report</h3><pre style='white-space: pre-wrap; font-family: Inter, sans-serif;'>{response.text}</pre></div>", unsafe_allow_html=True)
        except Exception as e:
            st.error(f"❌ Analysis failed: {str(e)}")
            with st.expander("🔧 Error details"):
                import traceback
                st.code(traceback.format_exc())

# About section
st.markdown("""
<div id='about' style='margin-top:2rem; background: rgba(15,23,42,0.75); border: 1px solid rgba(148,163,184,0.4); border-radius:12px; padding:1.5rem;'>
  <h2>About MediScan AI</h2>
  <p>Advanced medical image diagnostics powered by AI for healthcare professionals. Fast, accurate, and easy to use.</p>
</div>
""", unsafe_allow_html=True)